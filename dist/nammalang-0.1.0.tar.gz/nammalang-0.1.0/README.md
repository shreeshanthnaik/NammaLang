# NammaLang

NammaLang is a Kannada-inspired programming language implemented in Python.

## Installation
```bash
pip install nammalang
